function wypisz_pole(){
  var y = document.forms[0].elements[0].value;
  document.write(typeof(y) + " y = " + y);
}
  //Tekst1 req, Tekst2 optional
  // var user_input = window.prompt("Tekst1","Tekst2");
// console.log('Tekst 1');
// window.alert('Tekst 2');
// document.write(user_input + " " + typeof(user_input));