var stylesheet = document.styleSheets[0];

function set_style(){
    stylesheet.disabled = false;
}

function unset_style(){
    stylesheet.disabled = true;
}